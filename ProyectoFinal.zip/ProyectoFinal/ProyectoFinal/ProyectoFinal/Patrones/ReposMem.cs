﻿using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Models.NoLogin;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectViews.Patrones
{
    public class ReposMem
    {
        String urlServer = "http://192.168.42.139/APICDS/CDSservices.asmx/getEventos";
        public ReposMem()
        {
            ResultEvents.listados = new List<ResultEvents>();
            //Inicializamos la base de datos

            ResultEvents result = new ResultEvents()
            {
                IdEvento = 1,
                TituloEvento = "BT7 El Salvador",
                Hora = DateTime.Now.ToString(),
                Fecha = DateTime.Today,
                Descripcion = "El evento tecnologico mas grande de El Salvador",
                imgEvento = "http://192.168.42.139/APICDS/img/bt7.png"
            };
            ResultEvents.listados.Add(result);
           
        }     
        public List<ResultEvents> Listaevents()
        {
            try
            {
                return ResultEvents.listados;
            }
            catch (Exception)
            {
                return null;
            }
        }
        //*******************************************************************************************************************************************************
        public List<UserDBLocal> ListaUser = new List<UserDBLocal>();

        public bool OperacionListas(UserDBLocal User, OperacionesFachada.Operaciones operaciones)
        {
            switch (operaciones)
            {
                case OperacionesFachada.Operaciones.Guardar:
                    ListaUser.Add(User);
                    return true;
                case OperacionesFachada.Operaciones.Editar:
                    return true;
                case OperacionesFachada.Operaciones.Eliminar:
                    int indexado = ListaUser.FindIndex(userr => userr.IdUsuario.Equals(User.IdUsuario));
                    ListaUser.RemoveAt(indexado);
                    return true;
                default:
                    return false;
            }
        }

        public UserDBLocal GetUserDBLocal(int Id, int IdUsuario)
        {
            try
            {
                //UBICACIÓN DEL REGISTRO EN LA LISTA
                int Index = ListaUser.FindIndex(userr => userr.ID.Equals(Id) && userr.IdUsuario.Equals(IdUsuario));
                return ListaUser[Index];
            }
            catch (Exception)
            {

                return null;
            }
        }
        public List<UserDBLocal> ObtenerUsuario()
        {
            return ListaUser;
        }

//*******************************************************************************************************************************************************

        public bool OperacionListas(ResultEvents Eventos,OperacionesFachada.Operaciones operaciones)
        {
            switch (operaciones)
            {
                case OperacionesFachada.Operaciones.Guardar:
                    ResultEvents.listados.Add(Eventos);
                    return true;
                case OperacionesFachada.Operaciones.Editar:
                    return true;
                case OperacionesFachada.Operaciones.Eliminar:
                    return true;
                default:
                    return false;
            }
        }
    }
}
