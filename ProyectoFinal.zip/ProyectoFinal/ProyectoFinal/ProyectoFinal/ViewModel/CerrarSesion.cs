﻿using ProyectoFinal.Models.NoLogin;
using System;
using Xamarin.Forms;
using ProyectoFinal.Models;
using System.Windows.Input;
using System.Threading.Tasks;
using ProyectoFinal.Views;

namespace ProyectoFinal.ViewModel
{
    public class CerrarSesion
    {
        public INavigation nNavegation { get; set; }
        public ICommand IrPerfil { get; set; }
        public ICommand IrBandeja { get; set; }

        Page _page;

        //Constructor de la clase
        public CerrarSesion(Page pPage, INavigation navegar)
        {
            _page = pPage;
            nNavegation = navegar;
            IrPerfil = new Command(Perfil);
            IrBandeja = new Command(Bandeja);
        }
        void Bandeja()
        {
            this.nNavegation.PushAsync(new BandejaChat());
        }
        void Perfil()
        {
            this.nNavegation.PushAsync(new Perfil());
        }
        public ICommand CerrarCommand { get { return new Command(async () => await CerrarSesion2()); } }

        private async Task CerrarSesion2()
        {
            try
            {
                await DBUser.Instance.conexion.QueryAsync<UserDBLocal>("DELETE FROM [UserDBLocal]");
                Settings.IsLoggedIn = false;               
                await nNavegation.PushAsync(new MainPage());
                this.nNavegation.RemovePage(this.nNavegation.NavigationStack[this.nNavegation.NavigationStack.Count - 2]);
            }
            catch (Exception)
            {
                //mensaje de error con conexion d einternet..
                await _page.DisplayAlert("Aviso", "Verifique la conexión a internet", "Aceptar");
            }
        }
   }          
}
    

