﻿using Newtonsoft.Json;
using ProyectoFinal.Models.Conexion;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using Xamarin.Forms;
using System.Linq;
using ProyectoFinal.Views;
using System.Windows.Input;

namespace ProyectoFinal.ViewModel
{
    public class vmBandejaMensajes : BindableObject
    {
        //comando para navegar
        INavigation navigation;
        
        public Command ItemSelected;
        //Lista de docentes
        private ObservableCollection<RestMensajesRecibidos> _mensajes;
        public ObservableCollection<RestMensajesRecibidos> Mensajes
        {
            get
            {
                return _mensajes;
            }
            set
            {
                if (_mensajes == value)
                {
                    return;
                }
                _mensajes = value;
                OnPropertyChanged("Mensajes");
            }
        }
        //Instancia de la clase que contiene los datos del Json
        RestMensajesRecibidos RestMensajes = new RestMensajesRecibidos();
        //Variable que contiene la Url
        string URL = "http://192.168.42.139/APICDS/CDSservices.asmx/getMensaje";
        //============================================================================================================================================
        //Encapsulamiento de datos
        //Variables para encapsular
        //public string Docente { get { return RestMensajes.Docente ; } set { RestMensajes.Docente = value; OnPropertyChanged(); } }
        //public string Participante { get { return RestMensajes.Participante; } set { RestMensajes.Participante = value; OnPropertyChanged(); } }
        //public string TituloMensaje { get { return RestMensajes.TituloMensaje; } set { RestMensajes.TituloMensaje = value; OnPropertyChanged(); } }
        //============================================================================================================================================       

        //==============
        //Constructor de la Clase que carga los datos
        public vmBandejaMensajes(INavigation nav)
        {
            this.navigation = nav;
            Mensajes = new ObservableCollection<RestMensajesRecibidos>();
            InboxMessage();
            ItemSelected = new Command<RestMensajesRecibidos>(OnItemSelected);
            
        }

        //Metodo para saber si es docente o participante
        public async void InboxMessage()
        {
            //Variables para verificar y asi mostrar que tipo de Usuario es...
            int IdDocent = 0;
            int IdParticipante = 0;
            HttpClient cliente = new HttpClient();
            String IdUsuario = "IdUsuario=";
            String docente = "docente=";
            //Validamos si es docente
            if (vmUsuario.userencontrado.esDocente)
            {
                IdDocent = vmUsuario.userencontrado.IdUsuario;
            }
            else
            {
                IdParticipante = vmUsuario.userencontrado.IdUsuario;
            }
            bool esDocente = vmUsuario.userencontrado.esDocente;
            //======================================================================================
            //Condicion
            if (IdDocent != 0)
            {
                var Usuario = IdUsuario + Convert.ToString(IdDocent);
                var Docente = docente + "1";
                //Instancia para el GET
                HttpResponseMessage Result = await cliente.GetAsync(this.URL + "?" + Usuario + "&" + Docente);
                if (Result != null)
                {
                    var contenido = await Result.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<RestMensajesRecibidos>>(contenido);
                    foreach (var item in resultados.OrderByDescending(c=>c.IdMensaje))
                    {
                        Mensajes.Add(item);
                    }

                }
            }
            else if (IdParticipante != 0)
            {
                var _Usuario = IdUsuario + Convert.ToString(IdParticipante);
                var _Docente = docente + "0";
                //Instancia para el GET
                HttpClient HtpCliente = new HttpClient();
                HttpResponseMessage Resulta = await HtpCliente.GetAsync(this.URL + "?" + _Usuario + "&" + _Docente);
                if (Resulta != null)
                {
                    var contenido = await Resulta.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<RestMensajesRecibidos>>(contenido);
                    foreach (var item in resultados.OrderByDescending(c => c.IdMensaje))
                    {
                        Mensajes.Add(item);
                    }
                }
            }

        }

        //metodos de navegacion
        public async void OnItemSelected(RestMensajesRecibidos mensajes)
        {
            Chat1 msj = new Chat1(mensajes);
            await navigation.PushAsync(msj);
        }

        


    }
}
