﻿using Newtonsoft.Json;
using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectViews.Patrones;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class Add
    {
        String urlServer = "http://192.168.42.139/APICDS/CDSservices.asmx/getEventos";
        String IdUsuario = "IdUsuario=";
        String docente = "docente=";

        
        public ObservableCollection<ResultEvents> Eventos { get; set; }
        
        public ICommand Regresar { get; set; }
        private Page txt;

        public Add()
        {
            Regresar = new Command(Volver);
            Eventos = new ObservableCollection<ResultEvents>();
            GetEventos();
        }

        private async void GetEventos()
        {
            HttpClient _client = new HttpClient();
            //RestClient client = new RestClient();
            //Armamos la URL del servicio
            this.IdUsuario += "1";
            this.docente += "0";
            //var APIR = await client.Get<ResultEvents>(this.urlServer + "?" + this.IdUsuario + "&" + this.docente);
            HttpResponseMessage respusta = await _client.GetAsync(this.urlServer + "?" + this.IdUsuario + "&" + this.docente);
            try
            {
                if (respusta != null)
                {
                    var contenido = await respusta.Content.ReadAsStringAsync();
                    var lista = JsonConvert.DeserializeObject<List<ResultEvents>>(contenido);
                    Eventos.Clear();
                    foreach (var item in lista)
                    {
                        Eventos.Add(item);
                    }

                }
            }
            catch (Exception)
            {

                throw;
            }

        }
        public async void Volver()
        {
            await PopupNavigation.Instance.PopAsync();
        }
    }

}

