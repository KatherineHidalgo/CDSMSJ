﻿using Newtonsoft.Json;
using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectViews;
using ProyectViews.Patrones;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{

    public class BaseLista : INotifyPropertyChanged
    {
        String IdUsuario = "IdUsuario=";
        String docente = "docente=";
        String urlServer = "http://192.168.42.139/APICDS/CDSservices.asmx/getEventos";
        private bool refresh;
        public event PropertyChangedEventHandler PropertyChanged;
        //Variable para verificar la actualizacion de la lista
        private ObservableCollection<ResultEvents> _listas;

        public ObservableCollection<ResultEvents> Listas
        {
            get
            {
                return _listas;
            }
            set
            {
                if (_listas == value)
                {
                    return;
                }
                _listas = value;
                OnPropertyChanged("Listas");
            }
        }
        private Command btnCommand;
        private Command _listaCommand;
        
        public Command CommandBtn
        {
            get
            {
                return btnCommand ?? (btnCommand = new Command(Click_Btn));
            }
        }
        public Command ListaCommand
        {
            get { return _listaCommand ?? (_listaCommand = new Command(CargarLista, () => { return !refresh; })); }
        }

        public Command IrnewUser { get; set; }
        public Command ItemSelected;
            
        public bool IsRefreshing
        {
            get { return refresh; }
            set
            {
                //Validamos si el objeto no posee cambios
                if (refresh == value)
                {
                    return;
                }
                //Asignamos el nuevo valor y notificamos que a cambiado
                refresh = value;
                //... Realizamos la notificación del cambio...
                OnPropertyChanged("IsRefreshing");
            }
        }
        public BaseLista()
        {
            Listas = new ObservableCollection<ResultEvents>();
            
            GetEventos();
                        
            ItemSelected = new Command<ResultEvents>(OnItemSelected);
        }
        public void Click_Btn()
        {
            this.CargarLista();
        }
       
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }


        public void CargarLista()
        {
            //Verificamos si existe un refresh
            if (refresh)
            {
                return;
            }
            refresh = true;
            ListaCommand.ChangeCanExecute();
            GetEventos();
            refresh = false;
            ListaCommand.ChangeCanExecute();
        }

        public async void GetEventos()
        {
            HttpClient _client = new HttpClient();
            //Armamos la URL del servicio
            
            var Usuario = IdUsuario + "1";
            var Docente = docente + "0";
            HttpResponseMessage respusta = await _client.GetAsync(this.urlServer + "?" + Usuario + "&" + Docente);
            try
            {
                if (respusta != null)
                {
                    var contenido = await respusta.Content.ReadAsStringAsync();
                    var lista = JsonConvert.DeserializeObject<List<ResultEvents>>(contenido);
                    Listas.Clear();
                    foreach (var item in lista)
                    {
                        Listas.Add(item);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public async void OnItemSelected(ResultEvents _eventos)
        {
            NewUserPopupPage popupevent = new NewUserPopupPage(_eventos);
            await PopupNavigation.Instance.PushAsync(popupevent);
        }
    }

}
