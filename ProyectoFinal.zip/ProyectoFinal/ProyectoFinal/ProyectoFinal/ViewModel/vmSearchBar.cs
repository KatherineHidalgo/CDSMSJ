﻿using Newtonsoft.Json;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class vmSearchBar 
    {
        //Url server
        String URLserver = "http://192.168.42.139/APICDS/CDSservices.asmx/ObtenerDocentes?";
        //Variable que mantiene el iD        

        //Variable de Cambio
        public event PropertyChangedEventHandler PropertyChanged;
        //Metodo de Cambio
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
    
        //Searchbar para los docentes
        //======================================================================
        public ObservableCollection<ResultDoc> _listas;
        public ObservableCollection<ResultDoc> ListasDoc
        {
            get { return _listas; }
            set
            {
                if (_listas == value)
                {
                    return;
                }
                _listas = value;
                OnPropertyChanged("ListasDoc");
            }
        }
        //====================
        
        //====================
        public vmSearchBar()
        {
            ListasDoc = new ObservableCollection<ResultDoc>();
            GetEventos();            
        }
        ////Searchbar
        public async void GetEventos()
        {

            HttpClient client = new HttpClient();
            HttpResponseMessage respuesta = await client.GetAsync(this.URLserver);
            try
            {
                if (respuesta != null)
                {
                    var contenido = await respuesta.Content.ReadAsStringAsync();
                    var lista = JsonConvert.DeserializeObject<List<ResultDoc>>(contenido);
                    ListasDoc.Clear();
                    foreach (var item in lista)
                    {
                        ListasDoc.Add(item);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        //========================================================================================
        
        //========================================================================================

    }


}
