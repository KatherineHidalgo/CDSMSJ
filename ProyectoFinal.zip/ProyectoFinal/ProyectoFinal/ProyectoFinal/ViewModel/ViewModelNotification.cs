﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.ViewModel
{
    public class ViewModelNotification
    {
        public static string mensaje;
        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }

        public ViewModelNotification()
        {
            this.Mensaje = mensaje;
        }
    }
}
