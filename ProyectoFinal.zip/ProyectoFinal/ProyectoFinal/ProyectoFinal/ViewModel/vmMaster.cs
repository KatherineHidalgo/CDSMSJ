﻿using ProyectoFinal.Views;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
  //public  class vmMaster
  //  {
  //      public ICommand IrPerfil { get; set; }
  //      public ICommand IrBandeja { get; set; }

  //      public INavigation nNavegation { get; set; }

  //      Page _page;

  //      //Constructor de la clase
  //      public vmMaster(Page pPage, INavigation navegar)
  //      {
  //          _page = pPage;
  //          nNavegation = navegar;
  //          IrPerfil = new Command(Perfil);
  //          IrBandeja = new Command(Bandeja);
  //      }
  //      void Bandeja()
  //      {
  //          this.nNavegation.PushAsync(new BandejaChat());
  //      }
  //      void Perfil()
  //      {
  //          this.nNavegation.PushAsync(new Perfil());
  //      }
  //  }
}
