﻿using Newtonsoft.Json;
using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinal.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Docentes : ContentPage
    {                        
        public Docentes()
        {            
            this.cargarInitialize();            
        }        
        void cargarInitialize()
        {                    
                InitializeComponent();
                BindingContext = new vmMessage(this, Navigation);           
            Listas = new ObservableCollection<ResultDoc>();
            GetEventos();
        }
        //Url server
        String URLserver = "http://192.168.42.139/APICDS/CDSservices.asmx/ObtenerDocentes?";
        //UrlServer participantes
        String UrlServerP = "http://192.168.42.139/APICDS/CDSservices.asmx/ObtenerParticipantes?";
        //Variable que mantiene el iD
        private static string idDc;
        public static string IDD
        {
            get { return idDc; }
            set { idDc = value; }
        }
        private static string idPart;
        public static string IDP
        {
            get { return idPart; }
            set { idPart = value; }
        }
        //Variable de Cambio
        public event PropertyChangedEventHandler PropertyChanged;
        //Metodo de Cambio
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        
        //Searchbar para los docentes
        //======================================================================
        public ObservableCollection<ResultDoc> _listas;
        public ObservableCollection<ResultDoc> Listas
        {
            get { return _listas; }
            set
            {
                if (_listas == value)
                {
                    return;
                }
                _listas = value;
                OnPropertyChanged("Listas");
            }
        }        

        ////Searchbar
        public async void GetEventos()
        {
            HttpClient client = new HttpClient();
            int IdDocent = vmUsuario.userencontrado.IdUsuario;
            bool esDocente = vmUsuario.userencontrado.esDocente;
            String IdUsuario = "IdUsuario=";
            var Usuario = IdUsuario + Convert.ToString(IdDocent);
            HttpResponseMessage respuesta = await client.GetAsync(this.URLserver);
            HttpResponseMessage respuesta1 = await client.GetAsync(this.UrlServerP + Usuario);

            try
            {
                if (respuesta1 != null & esDocente == true & IdDocent!=0)
                {                    
                        var contenido = await respuesta1.Content.ReadAsStringAsync();
                        var lista = JsonConvert.DeserializeObject<List<ResultDoc>>(contenido);
                        Listas.Clear();
                        foreach (var item in lista)
                        {
                            Listas.Add(item);
                        }
                                        
                }
                else if (respuesta !=null & esDocente == false)
                {
                    var contenido = await respuesta.Content.ReadAsStringAsync();
                    var listaP = JsonConvert.DeserializeObject<List<ResultDoc>>(contenido);
                    Listas.Clear();
                    foreach (var item in listaP)
                    {
                        Listas.Add(item);
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        
        ////evento de la busqueda en la searchbar
        private void SearchContent(object sender, TextChangedEventArgs e)
        {
            var Keyword = SearchBar.Text;
            if (Keyword.Length >= 1)
            {
                var suggestion = Listas.Where(c => c.Nombre.ToLower().Contains(Keyword.ToLower()));
                DocentesLista.ItemsSource = suggestion;
                DocentesLista.IsVisible = true;
               
            }
            else
            {
                DocentesLista.IsVisible = false;
            }
        }
        //seleccionar item de la lista
        private void NamesList(object sender, ItemTappedEventArgs e)
        {
            bool esDocente = vmUsuario.userencontrado.esDocente;
            if (e.Item as ResultDoc == null)
            {
                return;
            }
            else
            {
                if (esDocente == true)
                {
                    GetEventos();
                    DocentesLista.ItemsSource = Listas.Where(c => c.Nombre.Equals((e.Item as ResultDoc).Nombre));
                    DocentesLista.IsVisible = true;
                    SearchBar.Text = (e.Item as ResultDoc).Nombre;
                    idPart = SearchBar.Text = (e.Item as ResultDoc).IdParticipante.ToString();
                    
                }
                else if (esDocente == false)
                {
                    GetEventos();
                    DocentesLista.ItemsSource = Listas.Where(c => c.Nombre.Equals((e.Item as ResultDoc).Nombre));
                    DocentesLista.IsVisible = true;
                    SearchBar.Text = (e.Item as ResultDoc).Nombre;
                    idDc = SearchBar.Text = (e.Item as ResultDoc).IdDocento.ToString();

                }

            }
            
            //var IDoc = Listas.Where(x => x.IdDocento.Equals(idDocente));
        }
        public static void idDoc()
        {
            
        }

        
        //================================================================================================
    }
}