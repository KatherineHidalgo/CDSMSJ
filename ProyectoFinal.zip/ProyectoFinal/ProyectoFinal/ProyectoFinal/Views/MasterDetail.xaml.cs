﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProyectoFinal.Models;
using ProyectoFinal.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinal.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MasterDetail : MasterDetailPage
    {
        private int idUsuario;

        public MasterDetail(int idUsuario = 0)
        {
            InitializeComponent();            
            this.Master = new Master();
            this.Detail = new NavigationPage(new Detail());
            NavigationPage.SetHasNavigationBar(this, false);
            this.idUsuario = idUsuario;
        }

        //public MasterDetail(int idUsuario)
        //{
        //    this.idUsuario = idUsuario;
        //}
    }
}