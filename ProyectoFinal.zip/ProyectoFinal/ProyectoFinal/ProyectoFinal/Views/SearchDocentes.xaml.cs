﻿using Newtonsoft.Json;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinal.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class SearchDocentes : ContentPage, INotifyPropertyChanged
    {
        ////Url server par obtener los Docentes
        //String URLserver = "http://192.168.42.139/APICDS/CDSservices.asmx/ObtenerDocentes";
        ////URL server para obtener los participantes
        //String Urlserver = "http://192.168.42.139/APICDS/CDSservices.asmx/ObtenerParticipantes";


        ////Searchbar para los docentes
        ////=========================================================================================================  
        //public ObservableCollection<ResultDoc> _listas;
        //public ObservableCollection<ResultDoc> Listas
        //{
        //    get { return _listas; }
        //    set
        //    {
        //        if (_listas == value)
        //        {
        //            return;
        //        }
        //        _listas = value;
        //        OnPropertyChanged("Docentes");
        //    }
        //}

        ////Lista Bar para los participantes
        //private ObservableCollection<ResultParti> listas;
        //public ObservableCollection<ResultParti> Participantes
        //{
        //    get { return listas; }
        //    set
        //    {
        //        if (listas == value)
        //        {
        //            return;
        //        }
        //        listas = value;
        //        OnPropertyChanged("Participantes");
        //    }
        //}
        ////constructor
        //public SearchDocentes()
        //{
        //    InitializeComponent();
        //    Listas = new ObservableCollection<ResultDoc>();
        //    GetEventos();
        //}
        //////Searchbar
        //public async void GetEventos()
        //{
        //    //Instancia del cliente
        //    HttpClient _client = new HttpClient();
        //    //Variable para el url
        //    var IdUsuario = "IdUsuario=";
        //    int IdDocent = vmUsuario.userencontrado.IdDocente;
        //    int IdParticipante = vmUsuario.userencontrado.IdParticipante;
        //    bool esDocente = vmUsuario.userencontrado.esDocente;


        //    if (IdDocent != 0 & esDocente == true)
        //    {
        //        var urlPart = IdUsuario + Convert.ToString(IdDocent);
                

        //        //Get
        //        HttpResponseMessage Result = await _client.GetAsync(this.URLserver + "?" + urlPart);
        //        if (Result != null)
        //        {
        //            var contenido = await Result.Content.ReadAsStringAsync();
        //            var resultados = JsonConvert.DeserializeObject<List<ResultParti>>(contenido);
        //            foreach (var parti in resultados)
        //            {
        //                Participantes.Add(parti);
        //            }
        //        }
        //    }
        //    else if (IdParticipante != 0 & esDocente == false)
        //    {
        //        //Get
        //        HttpResponseMessage Result = await _client.GetAsync(this.URLserver + "?");
        //        if (Result != null)
        //        {
        //            var contenido = await Result.Content.ReadAsStringAsync();
        //            var resultados = JsonConvert.DeserializeObject<List<ResultDoc>>(contenido);
        //            foreach (var parti in resultados)
        //            {
        //                Docentes.Add(parti);
        //            }
        //        }
        //    }


        //}
        //private void SearchContent(object sender, TextChangedEventArgs e)
        //{
        //    GetUsuarios();
        //    var Keyword = SearchBDoc.Text;
        //    if (Keyword.Length >= 1)
        //    {
        //        var suggestion = Docentes.Where(c => c.Nombre.ToLower().Contains(Keyword.ToLower()));
        //        DocentesLista.ItemsSource = suggestion;
        //        DocentesLista.IsVisible = true;
        //    }
        //    else
        //    {
        //        DocentesLista.IsVisible = false;
        //    }
        //}


        //private void NamesList(object sender, ItemTappedEventArgs e)
        //{
        //    if (e.Item as ResultDoc == null)
        //    {
        //        return;
        //    }
        //    else
        //    {
        //        GetEventos();
        //        DocentesLista.ItemsSource = Listas.Where(c => c.Equals(e.Item as string));
        //        DocentesLista.IsVisible = true;
        //        SearchBar.Text = e.Item as string;
        //    }
        //}
        //=========================================================================================================

    }
}