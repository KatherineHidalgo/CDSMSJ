﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using ProyectoFinal.Views;
using ProyectoFinal.ViewModel;
using ProyectoFinal.Models;

namespace ProyectoFinal
{
	public partial class MainPage : ContentPage
	{
        //Constructor Principal
        public MainPage() {

            this.ConfiguracionInicial();
        }
        
        //Metodo para mostrar la Contraseña
        //=====================================================================
        public void ShowPass(object sender, EventArgs e)
        {
            LabelPassword.IsPassword = LabelPassword.IsPassword ? false : true;            
        }
        //=====================================================================

        //Metodo para la configuracion inicial
        private void ConfiguracionInicial() {
            InitializeComponent();
            Settings.IsLoggedIn = true;
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new vmUsuario(this, Navigation);
        }

       
    }
}
