﻿using ProyectoFinal.Models.Conexion;
using ProyectoFinal.ViewModel;
using ProyectoFinal.Views;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectViews
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NewUserPopupPage
    {       
		public NewUserPopupPage (ResultEvents eventos)
		{            
			InitializeComponent ();

            BindingContext = new Add();

            imagetxt.Source = eventos.imgEvento;
            txttitulo.Text = eventos.TituloEvento;
            descripciontxt.Text = eventos.Descripcion;
            horatxt.Text = eventos.Hora;
            fechatxt.Text = eventos.Fecha.ToString("dd/MM/yyyy");
        }                                                              
    }
}