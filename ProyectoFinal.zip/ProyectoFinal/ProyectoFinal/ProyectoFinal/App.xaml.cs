﻿using Com.OneSignal;
using Com.OneSignal.Abstractions;
using ProyectoFinal.Models;
using ProyectoFinal.Models.NoLogin;
using ProyectoFinal.ViewModel;
using ProyectoFinal.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace ProyectoFinal
{
    public partial class App : Application
    {
      

        public App()
        {
            InitializeComponent();
            if (Settings.IsLoggedIn)
            {
                try
                {
                    var Consulta = DBUser.Instance.conexion.QueryAsync<UserDBLocal>("SELECT * FROM  [UserDBLocal]").Result;               
                    int _idUser = Consulta.FirstOrDefault().IdUsuario;

                    vmUsuario.userencontrado = new Models.Conexion.ResultUser();
                    vmUsuario.userencontrado.IdUsuario = Consulta.FirstOrDefault().IdUsuario;
                    vmUsuario.userencontrado.esDocente = Consulta.FirstOrDefault().EsDocente;
                    MainPage = new NavigationPage(new MasterDetail(vmUsuario.userencontrado.IdUsuario));
                    //por si algo da error y el loge queda en true y no hay datos
                }
                catch (Exception)
                {
                    DBUser.Instance.conexion.QueryAsync<UserDBLocal>("DELETE FROM [UserDBLocal]");
                    Settings.IsLoggedIn = false;
                    MainPage = new NavigationPage(new MainPage());
                }
            }
            else
            {
                MainPage = new NavigationPage(new MainPage());
            }
            


           // MainPage = new NavigationPage(new MainPage());
            OneSignal.Current.StartInit("a318885a-4ef9-4378-bc0b-b25c00b8bb30")
            .HandleNotificationOpened(OnHandleNotificationOpended).EndInit();
            //Procesar el evento de la pagina principal(MainPage)
            MainPage.Appearing += (sender, e) =>
            {
                //Validar que el mensaje exista
                if (!String.IsNullOrEmpty(ViewModelNotification.mensaje))
                {
                    var informacionPage = new NotificacionesOneSignal
                    {
                        BindingContext = new ViewModelNotification()
                    };
                    var modelPage = new NavigationPage(informacionPage);
                    MainPage.Navigation.PushModalAsync(modelPage);
                    ViewModelNotification.mensaje = "";

                }
            };
            
        }
        //Metodo para procesar el evento de apertura de notificacion
        private void OnHandleNotificationOpended(OSNotificationOpenedResult result)
        {
            if (result.notification.payload.additionalData.ContainsKey("LlaveMsj"))
            {
                ViewModelNotification.mensaje = result.notification.payload.additionalData["LlaveMsj"].ToString();
            }
        }
        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
