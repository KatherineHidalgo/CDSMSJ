﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.Conexion
{
    public class ResultEvents
    {
        //Clase que contiene el Json
        public int IdEvento { get; set; }
        public string TituloEvento { get; set; }
        public string Hora { get; set; }
        public DateTime Fecha { get; set; }
        public string Descripcion { get; set; }
        public string imgEvento { get; set; }
        public static List<ResultEvents> listados;
    }
}
