﻿using Newtonsoft.Json;
using ProyectoFinal.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using ProyectoFinal.ViewModel;
using System.Threading.Tasks;
using Xamarin.Forms;
using ProyectoFinal.Views;

namespace ProyectoFinal.Models.Conexion
{
    public class RestMessage : BindableObject,  IMessage
    {
        //Url para el Acceso
        //===============================================================================
        String urlAccess = "http://192.168.42.139/APICDS/CDSservices.asmx/setMensaje";
        
            
        //===============================================================================

        //Conexion POST para poder Enviar Mensajes
        public async Task<bool> EnviarMensaje(Message message)
        {
            try
            {
                
                string IdDocent = Views.Docentes.IDD;
                string IdParticipante = Views.Docentes.IDP;
                //Instancia para obtener la varible de esDocente y asi verificar si es un Docente o Participante                           
                bool esDocente = ViewModel.vmUsuario.userencontrado.esDocente;
                var idDocenteEnvia = vmUsuario.userencontrado.IdUsuario;
                var idParticipanteEnvia = vmUsuario.userencontrado.IdUsuario;
                var idDocReceptor = IdDocent;
                var idPartReceptor = IdParticipante;


                if (esDocente == true)
                {
                    //Definicion del cliente par el consumo del webservices
                    HttpClient _client = new HttpClient();
                    ID iD = new ID();
                    var content = new FormUrlEncodedContent(
                    new KeyValuePair<string, string>[] {
                        new KeyValuePair<string, string>("titulo",message.TituloMsj),
                        new KeyValuePair<string, string>("mensaje",message.Text),
                        new KeyValuePair<string, string>("idUsuarioEnvia", Convert.ToString(idDocenteEnvia)),
                        new KeyValuePair<string, string>("enviaDocente","1"),
                        new KeyValuePair<string, string>("idUsuarioReceptor",IdParticipante),
                        new KeyValuePair<string, string>("receptorDocente","0")
                    });
                    var _response = _client.PostAsync(urlAccess, content).Result;
                    if (_response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        return await Task.FromResult(true);
                    }
                }
                else if (esDocente == false)
                {
                    //Definicion del cliente par el consumo del webservices
                    HttpClient _client = new HttpClient();
                    ID iD = new ID();
                    var content = new FormUrlEncodedContent(
                    new KeyValuePair<string, string>[] {
                        new KeyValuePair<string, string>("titulo",message.TituloMsj),
                        new KeyValuePair<string, string>("mensaje",message.Text),
                        new KeyValuePair<string, string>("idUsuarioEnvia",Convert.ToString(idParticipanteEnvia)),
                        new KeyValuePair<string, string>("enviaDocente","0"),
                        new KeyValuePair<string, string>("idUsuarioReceptor",idDocReceptor),
                        new KeyValuePair<string, string>("receptorDocente","1")
                    });
                    var _response = _client.PostAsync(urlAccess, content).Result;
                    if (_response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        return await Task.FromResult(true);
                    }
                }                                
                
                return await Task.FromResult(false);
            }
            catch (Exception)
            {

                return await Task.FromResult(false);
            }
        }

    }
}
