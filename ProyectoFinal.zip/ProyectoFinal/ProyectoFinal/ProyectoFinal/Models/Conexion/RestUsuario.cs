﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Models.Conexion
{
    public class RestUsuario
    {
        //Url de acceso
        public string urlAccess = "http://192.168.42.139/APICDS/CDSservices.asmx/ValidarUsuario";

        //conexion POST para el Login de los usuarios 
        public async Task<ResultUser> logUser(LoginJson loginJson)
        {
            try
            {
                //Definicion del cliente para el consumo del webservice
                HttpClient _client = new HttpClient();
                var content = new FormUrlEncodedContent(
                    new KeyValuePair<string, string>[]
                    {
                        new KeyValuePair<string, string>("login",loginJson.Login),
                        new KeyValuePair<string, string>("pass",loginJson.Pass)
                    });
                
                var _response = _client.PostAsync(urlAccess, content).Result;
                _response.EnsureSuccessStatusCode();
                String respuesta = await _response.Content.ReadAsStringAsync();
                ResultUser objRespuesta = JsonConvert.DeserializeObject<ResultUser>(respuesta);


                if (_response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return await Task.FromResult(objRespuesta);
                }
                return null;
            }
            catch (Exception)
            {

                return null;
            }
        }

    }
}
