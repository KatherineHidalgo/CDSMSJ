﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.NoLogin
{
   public class UserDBLocal
    {
        //id para poder borrar de reg de session actual
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        //Id del aparticipante a mantener iniciada la sesion...
        public int IdUsuario { get; set; }
        //Define si es un docente 
        public bool EsDocente { get; set; }
    }
}
