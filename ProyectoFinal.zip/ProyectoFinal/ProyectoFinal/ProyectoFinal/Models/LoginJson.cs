﻿using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class LoginJson : ObservableObject
    {
        //Clase de LOGIN para el Json del POST 

        [JsonProperty("login")]
        public string Login
        {
            get { return _login; }
            set { SetProperty(ref _login, value); }
        }
        string _login;

        [JsonProperty("pass")]
        public string Pass
        {
            get { return _pass; }
            set { SetProperty(ref _pass, value); }
        }
        string _pass;

        [JsonProperty("IdUsuario")]
        public int IdUsuario { get; set; }

        
    }
}
