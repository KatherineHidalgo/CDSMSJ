﻿using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class EventosJson : ObservableObject
    {        
        [JsonProperty("IDEvento")]
        public int IdEvento { get; set; }
        [JsonProperty("Titulo")]
        public string TituloEvento
        {
            get { return _tituloevento; }
            set { SetProperty(ref _tituloevento, value); }
        }
        string _tituloevento;
        [JsonProperty("Hora")]
        public string Hora
        {
            get { return _hora; }
            set { SetProperty(ref _hora, value); }
        }
        string _hora;
        [JsonProperty("Fecha")]
        public DateTime Fecha
        {
            get { return _fecha; }
            set { SetProperty(ref _fecha, value); }
        }
        DateTime _fecha;
        [JsonProperty("Descripcion")]
        public string Descripcion
        {
            get { return _descripcion; }
            set { SetProperty(ref _descripcion, value); }
        }
        string _descripcion;
        [JsonProperty("Imagen")]
        public string Imagen
        {
            get { return _image; }
            set { SetProperty(ref _image,value); }
        }
        string _image;
    }
}
