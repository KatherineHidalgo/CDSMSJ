﻿using Plugin.Settings;
using Plugin.Settings.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public static class Settings
    {
        //Esta clase sigue en proceso, funciona cuando el usuario se 
        //salga de la aplicacion no se le cierre sesion al momento de volver a entrar

        private static ISettings AppSettings
        {
            get
            {
                return CrossSettings.Current;
            }
        }
        #region Setting Constants

        private const string SettingsKey = "settings_key";
        private static readonly string SettingsDefault = string.Empty;
        private const string IsLoggedInToKenKey = "isloggedid_key";
        private static readonly bool IsLoggedInTokenDefault = false;

        #endregion
        public static string GeneralSettings
        {
            get
            {
                return AppSettings.GetValueOrDefault(SettingsKey, SettingsDefault);
            }
            set
            {
                AppSettings.AddOrUpdateValue(SettingsKey, value);
            }
        }
        public static bool IsLoggedIn
        {
            get { return AppSettings.GetValueOrDefault(IsLoggedInToKenKey, IsLoggedInTokenDefault); }
            set { AppSettings.AddOrUpdateValue(IsLoggedInToKenKey, value); }
        }
    }

}
