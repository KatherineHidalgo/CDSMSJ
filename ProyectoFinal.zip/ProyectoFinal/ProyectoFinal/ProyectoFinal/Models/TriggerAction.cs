﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace ProyectoFinal.Models
{
    public class TriggerAction : TriggerAction<Entry>
    {
        int aux = 0;
        protected override void Invoke(Entry sender)
        {
            try
            {
                if (sender.Text.Length >20)
                {
                    sender.FontSize -= 0.2;
                }
                else
                {
                    sender.FontSize += 0.2;
                }
                aux = sender.Text.Length;
            }
            catch (Exception)
            {

                throw;
            }
              
                     
        }
    }
}
