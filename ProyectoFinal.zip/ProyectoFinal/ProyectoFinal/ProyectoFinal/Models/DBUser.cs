﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Models.NoLogin
{
   public class DBUser
    {
        public SQLiteAsyncConnection conexion { get; set; }
        public static string Base = "dbPersona.db3";
        public static string Ubicacion = Ubicacion = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), Base);

        public DBUser()
        {
            CreateDB();
        }
        private void CreateDB()
        {
            try
            {
                //iniclializamos la coneccion 
                this.conexion = new SQLiteAsyncConnection(Ubicacion);
                //creamos las tablas
                this.conexion.CreateTableAsync<UserDBLocal>().Wait();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public Task<List<UserDBLocal>> QueryAsincrona(String sql)
        {
            //validamos que el sql no este vacio
            if (String.IsNullOrEmpty(sql))
            {
                //ejecutamos la consulta devolveido una lista de contastos
                return this.conexion.QueryAsync<UserDBLocal>(sql);
            }
            return null;
        }
        #region Singleton para acceder a instacia de DB
        private static DBUser _instance;
        public static DBUser Instance
        {
            get
            {
                return _instance ?? (new DBUser());
            }
        }
        #endregion
    }
}
